#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os,re,json,random
import openpyxl
import csv
import numpy as np

'''
Load the files in the folder directory, and return the absolute path list and corresponding label dictionary of all files in directory
'''
def list_all_files(x_path, label_path):
	filename = os.listdir(x_path)
	filelist = [os.path.join(x_path,file).replace('\\','/') for file in filename]
	tempdict = {}

	with open(label_path, 'r',encoding="utf-8-sig") as csvfile:
		reader = csv.reader(csvfile)
		number = 1
		for row in list(reader):
			if number==1:
				number = 0
				continue
			data_area = row[0].split('\t')
			tempdict[x_path + str(data_area[0])] = re.sub("[^0-9.+-]", "", str(data_area[1]))

	print("label file load Done!")
	return filelist,tempdict
	pass

def read_single_xlsx(filepath):
	datalist = []

	with open(filepath, 'r',encoding="utf-8-sig") as csvfile:
		reader = csv.reader(csvfile)
		for row in list(reader):
			line = []
			for cell in row:
				if cell=='':
					line.append(float(0))
				elif is_number(cell):
					line.append(float(cell))
				else:
					line.append(float(1))
			if len(line)==110:
				datalist.append(line)
			else:
				for i in range(0,110-len(line)):
					line.append(float(0))
				datalist.append(line)
	return datalist
	pass

def is_number(s):
	try:
		float(s)
		return True
	except ValueError:
		pass

	return False
