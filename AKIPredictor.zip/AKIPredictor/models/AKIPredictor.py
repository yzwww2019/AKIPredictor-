#!/usr/bin/env python
# -*- coding: utf-8 -*-

import numpy as np
import os, time, sys
import tensorflow as tf
from tensorflow.contrib import rnn

sys.path.append("..")
from utils import get_logger
from utils import get_next_batch
from utils import squence_padding
from utils import optimizer_adaptor

class Network(object):
    def __init__(self, args, config, num_classes=2,input_dim=110):
        self.batch_size = args.batch_size
        self.epoch_num = args.epoch
        self.hidden_dim = args.hidden_dim
        self.dropout = args.dropout
        self.optimizer = args.optimizer
        self.depth = args.depth
        self.layer = args.layer
        self.lr = args.lr
        self.clip_grad = args.clip
        self.num_tags = num_classes
        self.input_dim = input_dim
        self.shuffle = args.shuffle
        self.config = config
        self.beta1 = args.beta1
        self.attention_size = 50
        self.regular_lamda = 0.001
        self.is_bidirectional = True
        self.add_placeholders()
        self.LSTM_layer_op()

    def init_model_save_path(self,paths):
        self.model_path = os.path.join(paths['model_path'], "mymodel")  #Prefix the model
        self.summary_path = paths['summary_path']
        pass

    def add_placeholders(self):
        self.rawX = tf.placeholder(tf.float32, shape=[None, None, self.input_dim], name="rawX")
        self.labels = tf.placeholder(tf.int32, shape=[None,self.num_tags], name="labels")
        self.sequence_lengths = tf.placeholder(tf.int32, shape=[None], name="sequence_lengths")
        self.dropout_pl = tf.placeholder(dtype=tf.float32, shape=[], name="dropout")
        self.lr_pl = tf.placeholder(dtype=tf.float32, shape=[], name="lr")

    def LSTM_layer_op(self):
        for _ in range(self.layer):
            with tf.variable_scope(None, default_name="akipredictor-lstm-layer"):
                # bidirectional LSTM
                num_units = self.hidden_dim // 2
                cell_fw = rnn.LSTMCell(num_units,use_peepholes=False,activation='tanh')
                cell_bw = rnn.LSTMCell(num_units,use_peepholes=False,activation='tanh')
                (output_fw_seq, output_bw_seq), _ = tf.nn.bidirectional_dynamic_rnn(
                                                        cell_fw = cell_fw,
                                                        cell_bw = cell_bw,
                                                        inputs = self.rawX,
                                                        sequence_length = self.sequence_lengths,
                                                        dtype = tf.float32)

                output = tf.concat([output_fw_seq,output_bw_seq], 2)

                bilstm_output = tf.nn.dropout(output, self.dropout_pl)   ## dropout

                #  LSTM

                cell = rnn.LSTMCell(self.hidden_dim, use_peepholes=False, activation='tanh')

                outputs1, states = tf.nn.dynamic_rnn(cell = cell,
                                                        inputs = bilstm_output,
                                                        sequence_length = self.sequence_lengths,
                                                        dtype = tf.float32)

                outputs1 = tf.nn.dropout(outputs1, self.dropout_pl)

                outputs2, states = tf.nn.dynamic_rnn(cell=cell,
                                                        inputs=outputs1,
                                                        sequence_length=self.sequence_lengths,
                                                        dtype=tf.float32)

                outputs = tf.nn.dropout(outputs2, self.dropout_pl)

        with tf.variable_scope("akipredictor-attention"):
            hidden_size = outputs.shape[2].value

            # Trainable parameters
            w_omega = tf.Variable(tf.random_normal([hidden_size, self.attention_size], stddev=0.1))
            b_omega = tf.Variable(tf.random_normal([self.attention_size], stddev=0.1))
            u_omega = tf.Variable(tf.random_normal([self.attention_size], stddev=0.1))

            with tf.name_scope('v'):
                v = tf.tanh(tf.tensordot(outputs, w_omega, axes=1) + b_omega)
            vu = tf.tensordot(v, u_omega, axes=1, name='vu')
            alphas = tf.nn.softmax(vu, name='alphas')

            tf.summary.histogram('alphas', alphas)

            output = tf.reduce_sum(outputs * tf.expand_dims(alphas, -1), 1)

        with tf.variable_scope('akipredictor-full-connect-layer'):
            W = tf.get_variable(name="weight", dtype=tf.float32, shape=[self.hidden_dim,self.num_tags],
                                initializer=tf.contrib.layers.xavier_initializer())
            b = tf.get_variable(name="bias", dtype=tf.float32, shape=[self.num_tags],
                                initializer=tf.contrib.layers.xavier_initializer())
            fcl_input = tf.reshape(output, [-1, self.hidden_dim])
            fcl_output = tf.matmul(fcl_input,W) + b
            self.labels_softmax_ = tf.nn.softmax(fcl_output)

        ##loss function
        self.logits = fcl_output
        self.labels = tf.cast(self.labels, dtype=tf.float32)
        batch_cross_entropy = tf.nn.softmax_cross_entropy_with_logits_v2(logits = self.logits, labels = self.labels)
        self.entropy_loss = tf.reduce_mean(batch_cross_entropy)

        ##L2 regularization
        total_vars = tf.trainable_variables()
        L2_loss_regularization = [tf.nn.l2_loss(w) for w in total_vars]
        self.regular_loss = tf.reduce_mean(L2_loss_regularization)*self.regular_lamda/(2*self.batch_size)
        self.loss = self.entropy_loss + self.regular_loss
        tf.summary.scalar("loss", self.loss)

        ##Optimizer
        optimizer = optimizer_adaptor(self.optimizer,learning_rate = self.lr, adam_beta1 = self.beta1)
        self.global_step = tf.Variable(0, name="global_step", trainable=False)
        grads_and_vars = optimizer.compute_gradients(self.loss)
        grads_and_vars_clip = [[tf.clip_by_value(g, -self.clip_grad, self.clip_grad), v] for g, v in grads_and_vars]
        self.train_op = optimizer.apply_gradients(grads_and_vars_clip, global_step=self.global_step)

        pass

    def init_op(self):
        self.init_op = tf.global_variables_initializer()

    def addSummary(self, sess):
        self.merged = tf.summary.merge_all()
        self.file_writer = tf.summary.FileWriter(self.summary_path, sess.graph)

    def train_one_epoch(self, sess, train, epoch, saver, logger):
        num_batches = len(train) // self.batch_size
        start_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        batches = get_next_batch(train, self.batch_size, shuffle=self.shuffle)

        for step, batchsample in enumerate(batches):
            step_num = (epoch-1) * num_batches + step + 1

            feed_dict, _, _ = self.get_feed_dict(batchsample,self.lr,self.dropout)#Organize the dictionary fed into the neural network
            _, loss_train, summary = sess.run([self.train_op, self.loss, self.merged],
                                                        feed_dict=feed_dict)
            if step + 1 == 1 or (step + 1) % 200 == 0 or step + 1 == num_batches:
                logger.info('{} epoch {}, step {}, loss: {:.4}, global_step: {}'.format(
                                                                                start_time,
                                                                                epoch,
                                                                                step + 1,
                                                                                loss_train, step_num))
            self.file_writer.add_summary(summary, step_num)

    '''
    the predicted output of the model through the current training model of sess, without calculating loss
    '''
    def predict_one_epoch(self, sess, validate):
        rawx,rawy,rawseq = squence_padding(validate, self.input_dim)

        feed_dict = {self.rawX: np.array(rawx),
                     self.sequence_lengths: np.array(rawseq),
                     self.labels: np.array(rawy),
                     self.lr_pl: self.lr,
                     self.dropout_pl: self.dropout}
        predictions, losses = sess.run([self.labels_softmax_, self.loss], feed_dict=feed_dict)

        return predictions, np.array(rawy), losses
        pass

    def get_feed_dict(self, batch_sample, lr=None, dropout=None):
        rawx,rawy,rawseq = squence_padding(batch_sample, self.input_dim)

        feed_dict = {self.rawX: np.array(rawx),
                     self.sequence_lengths: np.array(rawseq),
                     self.labels: np.array(rawy)}
        
        if lr is not None:
            feed_dict[self.lr_pl] = lr
        else:
            feed_dict[self.lr_pl] = self.lr
        if dropout is not None:
            feed_dict[self.dropout_pl] = dropout
        else:
            feed_dict[self.dropout_pl] = self.dropout

        return feed_dict, rawseq, rawy

    def say_name(self):
        return "akipredictor_n{}_lay{}_drop{}_lr{}_bat{}".format(self.hidden_dim,
                                                            self.layer,
                                                            self.dropout,
                                                            self.lr,
                                                            self.batch_size
                                                            )
        